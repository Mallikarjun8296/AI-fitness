# Bicep curl form detection logic
