# Pull-up form detection logic
