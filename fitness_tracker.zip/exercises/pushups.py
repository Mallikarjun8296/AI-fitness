# Push-up form detection logic
