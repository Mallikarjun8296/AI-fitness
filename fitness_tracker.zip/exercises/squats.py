# Squat form detection logic
