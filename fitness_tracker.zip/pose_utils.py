# Helper functions for pose estimation, angle calculation
