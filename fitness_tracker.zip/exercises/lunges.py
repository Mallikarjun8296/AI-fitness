# Lunge form detection logic
